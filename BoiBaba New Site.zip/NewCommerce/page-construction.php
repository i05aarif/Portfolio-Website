<!DOCTYPE HTML>
<html <?php language_attributes(); ?>>
   <head>
      <meta charset="<?php bloginfo('charset'); ?>">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title><?php if (is_single() || is_page()) { wp_title('',true); } elseif(is_front_page()) { bloginfo('description'); } else { bloginfo('description'); } ?> | <?php bloginfo('name');?></title>
      <!-- fabicon -->
      <link rel="icon" type="image/png" href="<?php echo get_template_directory_uri();?>/img/fab.png"/>
      <!-- fabicon -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css" integrity="sha512-wR4oNhLBHf7smjy0K4oqzdWumd+r5/+6QO/vDda76MW5iug4PT7v86FoEkySIJft3XA0Ae6axhIvHrqwm793Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
      <!-- AoS-->
      <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
      <?php wp_head(); ?>
   </head>
   <body <?php body_class();?>>
     
	 
	<div class="container"style="text-align: center;margin-top: 7%;margin-bottom: 7%;">
	    
	 <div class="logo">
	    <img src="<?php echo get_template_directory_uri();?>/img/uc1.jpg" alt="" /style="width:350px;height:300px;margin-left: -2% !important">
	 </div>
	 
	 <h2 style="margin-top: 10px !important;background: red;padding: 10px;color: white;width: 50%;text-align: center;margin: 0px auto;
    margin-top: 0px;font-weight: bold;">For Order</h2>
	   <h3 style="margin-top: 15px;">
	       <a style="background: #fed700;padding: 10px;border-radius: 5px;cursor: pointer;color: #004cff;font-size: 25px;" href=" https://m.facebook.com/BoiBabacom-117670286812635/ "> Click To Find Facebook Page</a>
	   
	   
	  </h3>
	 
	 
	  <h3 style="color: red;font-weight: bold;margin-top: 15px;">Call: 01309081903</h3>
	 
	 
	 
	 
	 
	 
	</div>








<?php get_footer();?>