
<div class="sidebar">		
		<?php dynamic_sidebar('home_sidebar'); ?>
</div>