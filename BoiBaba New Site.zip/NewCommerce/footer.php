
<div class="footer">
	<div class="container">        
        <p>
            &copy; BoiBaba.com 2022 | <span>Made By <a href="#">Ariful</a></span>
        </p> 
    </div>
    <button onclick="topFunction()" id="go_top" title="Go to top"><i class="fas fa-angle-up"></i></button>
</div>








<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/jquery-3.6.0.min.js"></script>

<script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/bootstrap.min.js"></script>

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>



<?php wp_footer();?>
</body>
</html>