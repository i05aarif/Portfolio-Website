
      <div class="page_heading">
         <h2><a href="#">  Tab 1   <i class="fas fa-forward"></i></a></h2> 
      </div>
     <div class="row product_no_slider_row">
           <?php
                  $args = array(
                  'post_type'      => 'product',
                  'posts_per_page' => 10,
                  'order'           =>'DESC'
                  );
                  $loop = new WP_Query( $args );
                  while ( $loop->have_posts() ) : $loop->the_post();
                  global $product;
                  
                  ?>
         <div class="col-2 product_main_wrap tab_product_wrap">
            <div class="product_thumb_img">
               <a href="<?php the_permalink();?>"><?php echo woocommerce_get_product_thumbnail();?></a>
            </div>
            <div class="product_title_no_slide">
                     <a href="<?php the_permalink();?>"><?php the_title();?></a>
            </div>
         </div>
         <?php
                  endwhile;
                  
                  wp_reset_query(); 
                  ?>
      </div>