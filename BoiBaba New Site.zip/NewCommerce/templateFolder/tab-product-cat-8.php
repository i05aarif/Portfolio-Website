
      </br>
     <div class="row product_no_slider_row">
           <?php
                  $args = array(
                  'post_type'      => 'product',
                  'posts_per_page' => 10,
                  'order'           =>'DESC',
                  'product_cat'    => '৪র্থ শ্রেণীর থেকে ৮ম শ্রেণীর বই'
                  );
                  $loop = new WP_Query( $args );
                  while ( $loop->have_posts() ) : $loop->the_post();
                  global $product;
                  
                  ?>
         <div class="col-2 product_main_wrap tab_product_wrap tab_cat_with_price">
            <?php wc_get_template_part( 'content', 'product' );?>
         </div>
         <?php
                  endwhile;
                  
                  wp_reset_query(); 
                  ?>
      </div>