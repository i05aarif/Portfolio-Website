
<!------------------------------>
<section id="single_page_product_sec">
   <div class="container">
      <div class="page_heading" id="page_heading_single_product">
         <h2><a href="https://bit.ly/3wdNvqx"target="_blank">  Recently Sold </a></h2> 
      </div>
      <div class="row product_no_slider_row">
           <?php
                  $args = array(
                  'post_type'      => 'product',
                  'posts_per_page' => 8,
                  'order'           =>'DESC',
                  'product_cat'    => 'Recently Sold Books'
                  );
                  $loop = new WP_Query( $args );
                  while ( $loop->have_posts() ) : $loop->the_post();
                  global $product;
                  
                  ?>
         <div class="col-2 product_main_wrap_for_single_page tab_product_wrap tab_cat_with_price">
            <?php wc_get_template_part( 'content', 'product' );?>
         </div>
         <?php
                  endwhile;
                  
                  wp_reset_query(); 
                  ?>
      </div>
   </div>
</section>

<!-------------------------------->