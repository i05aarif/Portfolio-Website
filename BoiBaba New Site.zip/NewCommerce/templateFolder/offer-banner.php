
<section id="offer_banner" class="section_devider">
   <div class="container">
     <div class="row">
         <?php    
                  $wpnew=array(
                    'post_type'     =>'offer_banner',
                    'post_status'    =>'publish',
                     'posts_per_page'  =>1,
                     'paged'        =>$paged,                                   
                  );
                 $techCattNotFixe = new Wp_Query($wpnew);
                  while($techCattNotFixe->have_posts()){
                    $techCattNotFixe->the_post(); 
                ?>             

                <div class="offer_banner_image_hight_150px">
                   <?php the_post_thumbnail();?>
                </div>
               <?php }?> 
     </div>
   </div>
</section>
