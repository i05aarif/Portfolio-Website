<?php 

get_header();?>
<div class="top_banner_for_full_width">
   <?php the_post_thumbnail();?>
</div>
<div class="page_heading">
   
</div>
<div class="container">
   <div class="row">
      <div class="col-md-8">
          <h2>Leave A Message</h2>
         <?php   while(have_posts()) : the_post(); ?> 
         <p><?php the_content();?></p>
         <?php endwhile;?>
      </div>
      <div class="col-md-4 contact_wrap">
            <div class="contact_content_wrap">
              <h2>Corporate Office</h2>
			<p>147/3, D.I.T Extension Road, Fokirapool, Dhaka-1000.</p>
			
			<h2>Customer Service</h2>
			<p>Email: info@boibaba.com</p>
			<p>Mobile: 01309081903</p>  
            </div>
		</div>
      </div>
   </div>
<?php get_template_part('before-footer-widget'); ?> 
<?php get_footer();?>
