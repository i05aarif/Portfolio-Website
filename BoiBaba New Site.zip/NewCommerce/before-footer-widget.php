<section>
  <div class="before_footer_bg">
  <div class="container">
    <div class="row before_footer_widget_wrap">
        <div class="col-md-3">
         <?php dynamic_sidebar('footer_widgets_1st'); ?>
      </div>
      <div class="col-md-3">
         <?php dynamic_sidebar('footer_widgets_2st'); ?>
      </div>
      <div class="col-md-3">
          <?php dynamic_sidebar('footer_widgets_3rd'); ?>
      </div>
      <div class="col-md-3">
          <?php dynamic_sidebar('footer_widgets_4th'); ?>
          
         <div class="footer_widgets">
          <h2></h2>
          <div class="social_icon">
              <a href="https://www.facebook.com/BoiBabacom-117670286812635" target="_blank"><i class="fab fa-facebook-f"></i></a>
              
            <i class="fab fa-instagram"></i>
            <i class="fab fa-twitter"></i>
            <i class="fab fa-youtube"></i>
          </div>
         </div>
      </div>
    </div>
  </div>
</div>
</section>