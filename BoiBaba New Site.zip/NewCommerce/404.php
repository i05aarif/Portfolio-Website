<div class="" style="text-align: center;background: white;
width: 50%;
margin: 0 auto;
    margin-top: 0px;
padding: 5% 0% 8% 0%;
box-shadow: .2em .6em 1.2em #646464,-.5em -.5em 1em #fff;
border-radius: 15px;
margin-top: 10%;">
	<h1>Oops</h1>
	<h2>404 Error</h2>
	<h2>Page Not Found</h2>
	<a href="<?php echo home_url();?>"><button>Back To Home Page</button></a>
</div>