<?php get_template_part('header2'); ?> 
<!----------Slider Section---------->
<section id="slider_cat">
   <div class="container slider_cat_container">
      <div class="row">
         <div class="col-lg-3">
            <?php get_template_part('full-width-category'); ?> 
         </div>
         <div class="col-lg-9">
            <!-------------------->
            <div class="slider_wrap slick-single-item">
               <?php
                  global $post;
                  $args=array(
                  'posts_per_page'  =>-1,
                  'post_type'     =>'slider_item',
                  'page'        =>$paged,
                  'order'       =>'DESC');        
                    $allInfo= get_posts($args);
                    foreach ($allInfo as $post):setup_postdata($post);
                    $bannerImageURL= wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'slider_item');      
                    ?>
               <div class="slider_single_item">
                  <div class="slider_image">
                     <img src="<?php echo $bannerImageURL[0];?>"> 
                  </div>
               </div>
               <?php endforeach;?>
               <?php wp_reset_query();?>   
            </div>
            <!------------>
         </div>
         <!--------------------> 
      </div>
   </div>
</section>
<!---------Slider Section End-----------> 
<!----------Section 3 Post ----------> 
<section id="book_post_section">
   <div class="container">
      <div class="row">
         <?php    
            $wpnew=array(
              'post_type'     =>'3_book_post',
              'post_status'    =>'publish',
               'posts_per_page'  =>3,
               'paged'        =>$paged,                                   
            );
            $techCattNotFixe = new Wp_Query($wpnew);
            while($techCattNotFixe->have_posts()){
              $techCattNotFixe->the_post(); 
            ?>             
         <div class="col-lg-4 book_post_4">
            <div class="book_post_wrap">
               <div class="book_post_content">
                  <p><?php the_content();?></p>
                  <h3> <?php the_title();?></h3>
                  <?php 
                     $link = get_field('3_post_btn');
                     if( $link ): ?>
                  <a href="<?php echo esc_url( $link ); ?>"><button> Buy Now </button></a>
                  <?php endif; ?>
               </div>
               <div class="book_post_img">
                  <?php the_post_thumbnail();?>
               </div>
            </div>
         </div>
         <?php }?> 
      </div>
   </div>
</section>
<!----------Section 3 Post End---------->
<?php get_template_part('catFolder/recent-sold-cat'); ?> 

<!-- Product slider -->
<?php get_template_part('catFolder/ele-twelve-cat'); ?> 

<?php get_template_part('catFolder/joykoli-bichitra-cat'); ?> 

<!-- width banner -->
<?php get_template_part('templateFolder/offer-banner'); ?> 
<!-- width banner -->
<?php get_template_part('catFolder/nine-ten-cat'); ?> 


<!-- Tab -->
<?php get_template_part('tab-product'); ?>
<!-- Tab -->




<section id="service_short">
   <div class="container">
      <div class="row">
         <div class="col-md-3 support_info_wrap">
            <div class="support_info">
               <h2><i class="fas fa-truck"></i>  Quick Delivery</h2>
            </div>
         </div>
         <div class="col-md-3 support_info_wrap">
            <div class="support_info">
               <h2><i class="far fa-smile"></i>  Customer Satisfaction</h2>
            </div>
         </div>
         <div class="col-md-3 support_info_wrap">
            <div class="support_info">
               <h2><i class="fas fa-headset"></i>  24/7</h2>
            </div>
         </div>
         <div class="col-md-3 support_info_wrap">
            <div class="support_info">
               <h2><i class="fas fa-redo"></i>  7 Days for Return</h2>
            </div>
         </div>
      </div>
   </div>
</section>

<!-- Email Subscribe -->

<!-- Email Subscribe -->

<?php get_template_part('before-footer-widget'); ?> 
<?php get_footer();?>
