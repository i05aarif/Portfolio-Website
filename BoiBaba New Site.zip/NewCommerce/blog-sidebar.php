
<div class="blog_sidebar">			
	<?php dynamic_sidebar('sidebar_blog'); ?>
</div>