 <div class="full_width_category_wrap_mega_menu">
    <h2><i class="fas fa-bars"></i>   All Category</h2>
        <?php
           $args = array(
             'theme_location' => 'cat_mega_menu'
             );
                        
         wp_nav_menu( $args ); ?>
 </div>