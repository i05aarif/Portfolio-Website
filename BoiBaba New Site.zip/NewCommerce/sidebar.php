
<div class="sidebar_shop_page">
<?php dynamic_sidebar('shop_page_sidebar'); ?>
</div>