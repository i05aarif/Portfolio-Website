<section id="tab_section"class="section_devider">
   <div class="container">
      <div class="row">
         <div class="col-md-3 tab_banner_long">
            <?php    
               $wpnew=array(
                 'post_type'     =>'tab_banner',
                 'post_status'    =>'publish',
                  'posts_per_page'  =>1,
                  'paged'        =>$paged,                                   
               );
               $techCattNotFixe = new Wp_Query($wpnew);
               while($techCattNotFixe->have_posts()){
                 $techCattNotFixe->the_post(); 
               ?>             
            <div class="tab_banner_img">
               <?php the_post_thumbnail();?>
            </div>
            <?php }?> 
         </div>
         <div class="col-md-9 tab_col">
            <nav>
               <div class="nav nav-tabs tab_class" id="nav-tab" role="tablist">
                <!--  -->
                  <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true"> ৪র্থ-৮ম শ্রেণী   </button>
                  <!--  -->
                  
               </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">
                 <!--  -->
               <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                  <?php get_template_part('templateFolder/tab-product-cat-8'); ?> 
               </div>
               <!--  -->
              
              
            </div>
         </div>
      </div>
   </div>
</section>
